import 'package:flutter/material.dart';
import 'package:muslimas_project/main_pages/product_lists.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

import 'intro_pages/introduction_page_1.dart';
import 'intro_pages/introduction_page_2.dart';
import 'intro_pages/introduction_page_3.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  bool onInitial = true;
  bool onLast = false;

  final PageController _controller = PageController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        actions: [
          !onLast
              ? GestureDetector(
                  onTap: () {},
                  child: const Padding(
                    padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                    child: Text(
                      "skip",
                      style: TextStyle(color: Colors.black),
                    ),
                  ),
                )
              : SizedBox.shrink()
        ],
      ),
      body: Stack(
        children: [
          PageView(
            controller: _controller,
            onPageChanged: (index) {
              setState(() {
                onInitial = (index == 0);
                onLast = (index == 2);
              });
            },
            children: const [
              IntroPage1(),
              IntroPage2(),
              IntroPage3(),
            ],
          ),
          Container(
            alignment: Alignment(0, 0.85),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                !onInitial
                    ? TextButton(
                        onPressed: () {
                          _controller.previousPage(
                              duration: Duration(milliseconds: 500),
                              curve: Curves.easeIn);
                        },
                        child: const Text("prev",
                            style: TextStyle(color: Colors.red, fontSize: 18)),
                      )
                    : const SizedBox(
                        width: 55,
                      ),
                SmoothPageIndicator(
                  controller: _controller,
                  count: 3,
                  effect: const ExpandingDotsEffect(
                      dotColor: Colors.grey,
                      dotHeight: 10,
                      dotWidth: 10,
                      activeDotColor: Colors.black),
                ),
                !onLast
                    ? TextButton(
                        onPressed: () {
                          _controller.nextPage(
                              duration: Duration(milliseconds: 500),
                              curve: Curves.easeIn);
                        },
                        child: const Text(
                          "next",
                          style: TextStyle(color: Colors.red, fontSize: 18),
                        ),
                      )
                    : MaterialButton(
                        minWidth: 65,
                        height: 27,
                        shape: const StadiumBorder(),
                        color: Colors.red,
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (c)=> ProductsPage()));
                        },
                        child: Text("start", style: TextStyle(
                          color: Colors.white,
                          fontSize: 14
                        ),),
                      )
              ],
            ),
          )
        ],
      ),
    );
  }
}
